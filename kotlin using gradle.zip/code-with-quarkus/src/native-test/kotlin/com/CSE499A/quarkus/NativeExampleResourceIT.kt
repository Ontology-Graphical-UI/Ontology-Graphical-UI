package com.CSE499A.quarkus

import io.quarkus.test.junit.NativeImageTest

@NativeImageTest
open class NativeExampleResourceIT : ExampleResourceTest()